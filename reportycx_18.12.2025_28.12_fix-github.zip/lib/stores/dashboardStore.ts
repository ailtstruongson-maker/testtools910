
import { writable, get } from 'svelte/store';
import type { AppState, FilterState, ProcessedData } from '../types';
import { getSampleData } from '../services/sampleData';
import { processDashboardData } from '../services/dataProcessor';

export type ViewType = 'dashboard' | 'efficiency' | 'tax' | 'coupon' | 'shift' | 'checklist';

export const currentView = writable<ViewType>('dashboard');
export const appState = writable<AppState>('upload');
export const isProcessing = writable(false);
export const processedData = writable<ProcessedData | null>(null);
export const fileInfo = writable({ filename: '', savedAt: '' });
export const productConfig = writable<Record<string, number>>({});
export const departmentMap = writable<Record<string, string>>({});
export const kpiTargets = writable({ hieuQua: 40, traGop: 45 });
export const toastMessage = writable<{message: string, type: 'success' | 'error' | 'info'} | null>(null);

export const isDeduplicationEnabled = writable(true);

export const customTabs = writable<any[]>([]);
export const processingTime = writable(0);
let timerInterval: any;

function startTimer() {
  stopTimer();
  processingTime.set(0);
  const start = Date.now();
  timerInterval = setInterval(() => {
    processingTime.set(Date.now() - start);
  }, 100);
}

function stopTimer() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

export function showToast(message: string, type: 'success' | 'error' | 'info' = 'info') {
  const displayMsg = message.length > 100 && type === 'error'
    ? "Đã có lỗi xảy ra. Vui lòng mở Console (F12) để xem chi tiết." 
    : message;

  toastMessage.set({ message: displayMsg, type });
  setTimeout(() => toastMessage.set(null), 5000);
}

let worker: Worker | null = null;
let workerTimeout: any;

export function getWorker() {
  if (!worker) {
    try {
      worker = new Worker(new URL('../services/worker.ts', import.meta.url), { type: 'module' });
      worker.onmessage = async (e) => {
        // Xóa timeout khi nhận được phản hồi
        if (workerTimeout) clearTimeout(workerTimeout);

        const { type, payload, message } = e.data;
        
        if (type === 'SUCCESS') {
          processedData.set(payload);
          appState.set('dashboard');
          finalizeProcessing();
        } else if (type === 'FILTER_SUCCESS') {
          processedData.set(payload);
          isProcessing.set(false);
        } else if (type === 'ERROR') {
          console.error(message); // Log full debug info to console
          showToast(message, 'error');
          isProcessing.set(false);
          appState.set('upload');
          stopTimer();
        }
      };
      
      worker.onerror = (e) => {
        console.error("Worker Error:", e);
        showToast("Lỗi hệ thống Worker. Vui lòng tải lại trang.", "error");
        isProcessing.set(false);
        appState.set('upload');
        stopTimer();
      };

    } catch (err) {
      console.error("Failed to create worker:", err);
      showToast("Trình duyệt không hỗ trợ Web Worker.", "error");
    }
  }
  return worker;
}

function finalizeProcessing() {
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      setTimeout(() => {
        isProcessing.set(false);
        stopTimer();
      }, 500);
    });
  });
}

export const filterState = writable<FilterState>({
    kho: 'all', xuat: 'all', trangThai: [], nguoiTao: [], department: [],
    startDate: '', endDate: '', dateRange: 'all',
    industryGrid: { selectedGroups: [], selectedSubgroups: [] },
    summaryTable: {
        parent: [], child: [], manufacturer: [], creator: [], product: [],
        drilldownOrder: ['parent', 'child'], sort: { column: 'totalRevenue', direction: 'desc' }
      }
});

export const industryDrilldownPath = writable<string[]>([]);
export const uniqueFilters = writable({
  kho: [] as string[],
  nguoiTao: [] as string[],
  trangThai: [] as string[]
});

export function triggerFileUpload(file: File) {
  appState.set('loading');
  isProcessing.set(true);
  startTimer();

  const w = getWorker();
  if (w) {
    // Đặt timeout 120 giây cho file lớn
    workerTimeout = setTimeout(() => {
      console.error("Worker Timed Out");
      showToast("File quá lớn hoặc xử lý quá lâu. Vui lòng thử lại với file nhỏ hơn.", "error");
      if (worker) {
        worker.terminate();
        worker = null; // Reset worker để thử lại lần sau
      }
      isProcessing.set(false);
      appState.set('upload');
      stopTimer();
    }, 120000);

    w.postMessage({ 
      type: 'IMPORT_FILE', 
      payload: { 
        file, 
        enableDeduplication: get(isDeduplicationEnabled) 
      } 
    });
  } else {
    showToast("Không thể khởi tạo bộ xử lý nền.", "error");
    isProcessing.set(false);
    appState.set('upload');
    stopTimer();
  }
}

export async function loadSampleData() {
  appState.set('loading');
  isProcessing.set(true);
  startTimer();
  
  fileInfo.set({
    filename: 'YCX_SAMPLE_DATA_BI2.0.xlsx',
    savedAt: new Date().toLocaleTimeString('vi-VN')
  });

  setTimeout(() => {
    const sample = getSampleData();
    const result = processDashboardData(sample);
    
    uniqueFilters.set({
      kho: [...new Set(sample.map(r => r.normalizedKho).filter(Boolean) as string[])],
      nguoiTao: [...new Set(sample.map(r => r.normalizedNguoiTao).filter(Boolean) as string[])],
      trangThai: [...new Set(sample.map(r => r.normalizedTrangThai).filter(Boolean) as string[])]
    });

    processedData.set(result);
    appState.set('dashboard');
    finalizeProcessing();
    showToast("Đã nạp dữ liệu mẫu thành công!", "success");
  }, 1500);
}

let filterTimeout: any;
filterState.subscribe(fs => {
  const currentData = get(processedData);
  const currentState = get(appState);
  if (worker && currentData && currentState === 'dashboard') {
    clearTimeout(filterTimeout);
    filterTimeout = setTimeout(() => {
      isProcessing.set(true);
      worker?.postMessage({ type: 'APPLY_FILTER', payload: fs });
    }, 250);
  }
});
