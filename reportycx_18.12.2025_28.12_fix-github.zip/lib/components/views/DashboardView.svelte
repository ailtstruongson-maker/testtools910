
<script lang="ts">
  import { fade } from 'svelte/transition';
  import { 
    processedData, 
    isProcessing,
    appState
  } from '../../stores/dashboardStore';
  
  import Header from '../layout/Header.svelte';
  import KpiCards from '../kpis/KpiCards.svelte';
  import FilterBar from '../layout/FilterBar.svelte';
  import TrendChart from '../charts/TrendChart.svelte';
  import IndustryGrid from '../charts/IndustryGrid.svelte';
  import EmployeeAnalysis from '../employees/EmployeeAnalysis.svelte';
  import SummaryTable from '../tables/SummaryTable.svelte';
  import ProcessingLoader from '../common/ProcessingLoader.svelte';

  // Khi đang nạp file hoặc đang render dashboard lần đầu, hiện Loader toàn màn hình
  $: showFullLoader = $isProcessing && ($appState === 'loading' || ($appState === 'dashboard' && $processedData !== null));
  
  // Trạng thái mờ nhẹ khi chỉ đang lọc dữ liệu (không phải nạp file mới)
  $: isFilteringOnly = $isProcessing && $appState === 'dashboard' && !showFullLoader;
</script>

<div class="relative min-h-screen pb-20">
  <Header />
  <FilterBar />

  <!-- Container Dashboard: Chỉ thực sự hiển thị (alpha 1) khi không còn processing -->
  <div 
    class="space-y-8 relative transition-all duration-700 ease-in-out
      {$isProcessing ? 'opacity-0 scale-[0.98] pointer-events-none' : 'opacity-100 scale-100'}"
  >
    {#if $processedData}
      <KpiCards />
      
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <TrendChart />
        <IndustryGrid />
      </div>

      <EmployeeAnalysis />
      
      <div class="mt-8">
        <SummaryTable />
      </div>
    {:else}
      <div class="flex flex-col items-center justify-center py-40 opacity-20">
        <i data-lucide="database" class="w-20 h-20 mb-4"></i>
        <p class="font-black uppercase tracking-widest text-sm">Hệ thống sẵn sàng</p>
      </div>
    {/if}
  </div>

  <!-- Thông báo cập nhật bộ lọc (Dạng bubble nhỏ) -->
  {#if isFilteringOnly}
    <div class="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[60]" transition:fade={{ duration: 150 }}>
       <div class="flex items-center gap-3 px-6 py-4 bg-white/90 dark:bg-slate-800/90 backdrop-blur-xl rounded-3xl shadow-2xl border border-indigo-100 dark:border-indigo-900/50">
         <div class="w-5 h-5 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
         <span class="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-widest">Đang tính toán...</span>
       </div>
    </div>
  {/if}

  <!-- Loader toàn màn hình - Giữ cho đến khi rAF hoàn tất -->
  {#if showFullLoader}
    <div class="fixed inset-0 z-[1000]">
      <ProcessingLoader progress={0} message="Đang lắp đầy Dashboard..." />
    </div>
  {/if}
</div>

<style>
  /* Ngăn cuộn trang khi đang hiển thị loader toàn màn hình */
  :global(body:has(.fixed.inset-0.z-\[1000\])) {
    overflow: hidden;
  }
</style>
