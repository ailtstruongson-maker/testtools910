
<script lang="ts">
  import UploadSection from '../upload/UploadSection.svelte';
  import { loadSampleData } from '../../stores/dashboardStore';
  import { fade, fly } from 'svelte/transition';
  import { Icon } from '../common/Icon';

  const features = [
    { 
      title: "Trực quan hóa", 
      desc: "Biểu đồ xu hướng đa chiều theo ca và ngày.", 
      icon: "bar-chart-3", 
      color: "bg-blue-500" 
    },
    { 
      title: "Khai thác NV", 
      desc: "Theo dõi khả năng bán kèm của từng nhân sự.", 
      icon: "users", 
      color: "bg-emerald-500" 
    },
    { 
      title: "Trợ lý AI", 
      desc: "Tự động đưa ra nhận xét và cảnh báo hiệu suất.", 
      icon: "sparkles", 
      color: "bg-purple-500" 
    }
  ];
</script>

<div class="relative min-h-[85vh] flex flex-col items-center justify-center px-4 py-12 overflow-hidden" in:fade>
  
  <!-- Nền Blur Blobs động -->
  <div class="absolute inset-0 pointer-events-none overflow-hidden">
    <div class="absolute top-[10%] -left-20 w-96 h-96 bg-purple-400/10 dark:bg-purple-600/5 rounded-full blur-[100px] animate-blob"></div>
    <div class="absolute bottom-[10%] -right-20 w-96 h-96 bg-indigo-400/10 dark:bg-indigo-600/5 rounded-full blur-[100px] animate-blob animation-delay-2000"></div>
  </div>

  <div class="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-12 gap-16 items-center relative z-10">
    
    <!-- Hero Text (Bên trái) -->
    <div class="lg:col-span-7 text-left space-y-8">
      <div in:fly={{ x: -30, duration: 800 }}>
        <div class="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 rounded-2xl text-xs font-black tracking-widest uppercase mb-6 border border-indigo-100 dark:border-indigo-800 shadow-sm backdrop-blur-md">
          <span class="relative flex h-2 w-2">
            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
            <span class="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
          </span>
          Intelligence Hub 2.0
        </div>
        <h1 class="text-6xl md:text-8xl font-black text-slate-900 dark:text-white mb-6 tracking-tighter leading-[0.9]">
          Phân tích <br/> <span class="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">Yêu Cầu Xuất.</span>
        </h1>
        <p class="text-slate-500 dark:text-slate-400 text-xl font-medium max-w-lg leading-relaxed">
          Biến dữ liệu thô thành lợi nhuận. Tự động hóa báo cáo, tối ưu quy trình khai thác nhân sự chỉ trong vài giây.
        </p>
      </div>

      <!-- Feature Grid -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4" in:fly={{ y: 30, duration: 1000, delay: 200 }}>
        {#each features as feat}
          <div class="p-5 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group">
            <div class="w-10 h-10 {feat.color} text-white rounded-xl flex items-center justify-center mb-4 group-hover:rotate-12 transition-transform shadow-lg">
              <Icon name={feat.icon} size={5} />
            </div>
            <h3 class="font-black text-slate-800 dark:text-white text-sm mb-1">{feat.title}</h3>
            <p class="text-[10px] text-slate-400 font-bold leading-tight">{feat.desc}</p>
          </div>
        {/each}
      </div>
    </div>

    <!-- Right Side: Upload Card with Glow -->
    <div class="lg:col-span-5 w-full space-y-6" in:fly={{ x: 30, duration: 800 }}>
      <div class="relative group">
        <!-- Glow Effect Layer -->
        <div class="absolute -inset-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-[3.1rem] blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
        
        <div class="relative p-1 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 rounded-[3rem] shadow-2xl">
          <div class="bg-white dark:bg-slate-950 rounded-[2.8rem] p-2 overflow-hidden">
            <UploadSection />
          </div>
        </div>
      </div>
      
      <div class="flex items-center gap-4 py-2 px-8">
        <div class="h-px bg-slate-200 dark:bg-slate-800 flex-grow"></div>
        <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Hoặc trải nghiệm nhanh</span>
        <div class="h-px bg-slate-200 dark:bg-slate-800 flex-grow"></div>
      </div>

      <button 
        on:click={loadSampleData}
        class="w-full py-5 px-8 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl flex items-center justify-between group hover:border-indigo-500 transition-all shadow-sm"
      >
        <div class="flex items-center gap-4">
          <div class="w-12 h-12 bg-white dark:bg-slate-800 rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
            <Icon name="play" size={5} className="text-indigo-600" />
          </div>
          <div class="text-left">
            <span class="block text-sm font-black text-slate-800 dark:text-white uppercase tracking-wider">Dùng thử dữ liệu mẫu</span>
            <span class="text-[10px] font-bold text-slate-400">Khám phá toàn bộ tính năng ngay</span>
          </div>
        </div>
        <Icon name="arrow-right" size={4} className="text-slate-300 group-hover:text-indigo-500 transition-colors" />
      </button>
    </div>

  </div>
</div>

<style>
  .text-transparent {
    -webkit-background-clip: text;
    background-clip: text;
  }
  
  @keyframes blob {
    0% { transform: translate(0px, 0px) scale(1); }
    33% { transform: translate(30px, -50px) scale(1.1); }
    66% { transform: translate(-20px, 20px) scale(0.9); }
    100% { transform: translate(0px, 0px) scale(1); }
  }
  .animate-blob {
    animation: blob 10s infinite;
  }
  .animation-delay-2000 {
    animation-delay: 2s;
  }
</style>
