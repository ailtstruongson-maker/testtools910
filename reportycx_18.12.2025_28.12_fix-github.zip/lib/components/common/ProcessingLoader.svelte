
<script lang="ts">
  import { processingTime } from '../../stores/dashboardStore';
  import { fade, fly } from 'svelte/transition';
  import Icon from './Icon.svelte';

  export let message: string = "Đang phân tích hệ thống";
  export let progress: number = 0;

  $: seconds = ($processingTime ? ($processingTime / 1000).toFixed(1) : "0.0");
</script>

<div 
  class="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-950/30 backdrop-blur-xl"
  transition:fade={{ duration: 400 }}
>
  <!-- Card Container -->
  <div 
    class="relative w-full max-w-[340px] bg-white/10 dark:bg-slate-900/40 backdrop-blur-2xl border border-white/20 dark:border-slate-700/50 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.4)] rounded-[3rem] p-10 flex flex-col items-center text-center overflow-hidden"
    in:fly={{ y: 30, duration: 800, opacity: 0 }}
  >
    <!-- Background Glows -->
    <div class="absolute -top-24 -left-24 w-48 h-48 bg-indigo-500/10 rounded-full blur-[60px] pointer-events-none"></div>
    <div class="absolute -bottom-24 -right-24 w-48 h-48 bg-purple-500/10 rounded-full blur-[80px] pointer-events-none"></div>

    <!-- AI Core Visual -->
    <div class="relative mb-8 h-20 w-20 flex items-center justify-center">
      <div class="absolute inset-0 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-full animate-spin opacity-20" style="animation-duration: 4s;"></div>
      <div class="absolute inset-1.5 bg-slate-900/80 rounded-full backdrop-blur-md"></div>
      <div class="relative h-12 w-12 bg-gradient-to-br from-indigo-500 to-violet-500 shadow-[0_0_20px_rgba(99,102,241,0.5)] rounded-2xl flex items-center justify-center text-white">
        <Icon name="sparkles" size={6} className="animate-pulse" />
      </div>
    </div>

    <!-- Status -->
    <div class="space-y-2 mb-8">
      <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-indigo-300 text-[10px] font-normal uppercase tracking-[0.3em]">
        <span class="relative flex h-1.5 w-1.5">
          <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
          <span class="relative inline-flex rounded-full h-1.5 w-1.5 bg-indigo-500"></span>
        </span>
        AI Core Active
      </div>
      <h3 class="text-lg font-light text-white leading-tight tracking-tight italic">
        {message}
      </h3>
    </div>

    <!-- Stopwatch -->
    <div class="flex items-baseline gap-1.5 mb-8">
      <span class="text-6xl font-light text-white font-mono tabular-nums tracking-tighter leading-none opacity-90">
        {seconds}
      </span>
      <span class="text-sm font-normal text-indigo-400 uppercase tracking-widest leading-none">s</span>
    </div>

    <!-- Progress Bar with Shimmer -->
    <div class="w-full space-y-3">
      <div class="relative h-1 w-full bg-white/5 rounded-full overflow-hidden">
        <!-- Shimmer overlay -->
        <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent w-full -translate-x-full animate-shimmer z-10"></div>
        
        <div 
          class="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-500 bg-[length:200%_100%] animate-gradient-move transition-all duration-1000 ease-out rounded-full shadow-[0_0_15px_rgba(99,102,241,0.3)]"
          style="width: {progress > 0 ? progress : 15}%"
        ></div>
      </div>
      <div class="flex justify-between items-center px-1">
        <span class="text-[9px] font-normal text-slate-400 uppercase tracking-[0.2em]">Cấu trúc dữ liệu</span>
        <span class="text-[10px] font-bold text-indigo-400">{Math.round(progress)}%</span>
      </div>
    </div>
  </div>
</div>

<style>
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300&display=swap');

  .font-mono {
    font-family: 'JetBrains Mono', monospace;
  }

  @keyframes shimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
  }
  .animate-shimmer {
    animation: shimmer 2.5s infinite linear;
  }

  @keyframes gradient-move {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }
  .animate-gradient-move {
    animation: gradient-move 3s ease infinite;
  }
</style>
