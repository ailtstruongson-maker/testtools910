
<script lang="ts">
  export let className: string = '';
</script>

<div class="animate-pulse bg-slate-200 dark:bg-slate-700 rounded-lg {className}"></div>

<style>
  div {
    min-height: 1em;
  }
</style>
