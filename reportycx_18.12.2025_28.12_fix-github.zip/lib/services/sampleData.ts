
import type { DataRow } from '../types';

export const getSampleData = (): DataRow[] => {
  const employees = [
    '12345 - Nguyễn Văn Anh',
    '67890 - Trần Thị Bình',
    '11223 - Lê Văn Cường',
    '44556 - Phạm Minh Đức',
    '99887 - Hoàng Thanh Hà'
  ];

  const industries = [
    { name: 'Điện thoại', groups: ['iPhone', 'Samsung', 'Oppo'], price: 15000000 },
    { name: 'Laptop', groups: ['Macbook', 'Asus', 'HP'], price: 20000000 },
    { name: 'Phụ kiện', groups: ['Sạc dự phòng', 'Tai nghe BLT', 'Loa'], price: 500000 },
    { name: 'Gia dụng', groups: ['Máy lọc nước', 'Nồi chiên', 'Quạt điện'], price: 3500000 },
    { name: 'Bảo hiểm', groups: ['Bảo hiểm rơi vỡ', 'Bảo hiểm gia hạn'], price: 1200000 },
    { name: 'Sim', groups: ['Sim Online', 'Sim Số Đẹp'], price: 250000 }
  ];

  const warehouses = ['K001', 'K002', 'K003'];
  const data: DataRow[] = [];
  const now = new Date();

  // Tạo 200 dòng dữ liệu mẫu trong 7 ngày qua
  for (let i = 0; i < 200; i++) {
    const industry = industries[Math.floor(Math.random() * industries.length)];
    const employee = employees[Math.floor(Math.random() * employees.length)];
    const warehouse = warehouses[Math.floor(Math.random() * warehouses.length)];
    const date = new Date(now);
    date.setDate(date.getDate() - Math.floor(Math.random() * 7));
    date.setHours(8 + Math.floor(Math.random() * 13), Math.floor(Math.random() * 60));

    const price = industry.price * (0.8 + Math.random() * 0.4);
    const isShipped = Math.random() > 0.2;
    const isInstallment = Math.random() > 0.6;

    data.push({
      'Mã kho tạo': warehouse,
      'Trạng thái xuất': isShipped ? 'Đã xuất' : 'Chưa xuất',
      'Người tạo': employee,
      'Trạng thái hồ sơ': 'YCX-Hoàn tất',
      'Ngành hàng': industry.name,
      'Nhóm hàng': industry.groups[Math.floor(Math.random() * industry.groups.length)],
      'Số lượng': 1,
      'Giá bán_1': price,
      'Hình thức xuất': isInstallment ? 'Xuất bán hàng trả góp tại siêu thị' : 'Xuất bán hàng tại siêu thị',
      'Tên sản phẩm': `${industry.name} Model X${i}`,
      normalizedKho: warehouse,
      normalizedXuat: isShipped ? 'Đã' : 'Chưa',
      normalizedNguoiTao: employee,
      normalizedTrangThai: 'YCX-Hoàn tất',
      parsedDate: date
    });
  }

  return data;
};
