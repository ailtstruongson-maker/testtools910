
import * as XLSX from 'xlsx';
import { processDashboardData } from './dataProcessor';
import { applyAllFilters } from './filterService';

let cachedOriginalData: any[] = [];
let columnHeaders: string[] = [];

// Hàm chuẩn hóa chuỗi
function normalizeStr(str: any): string {
  if (!str) return '';
  return String(str)
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Tìm chỉ số cột dựa trên tên cột (so sánh mờ - fuzzy match)
 */
function getColIndex(headers: string[], validNames: string[]): number {
  const normValidNames = validNames.map(n => normalizeStr(n));
  
  // Ưu tiên tìm khớp chính xác trước
  let index = headers.findIndex(h => {
    const normH = normalizeStr(h);
    return normValidNames.some(v => normH === v);
  });

  if (index !== -1) return index;

  // Nếu không thấy, tìm khớp một phần (contains)
  return headers.findIndex(h => {
    const normH = normalizeStr(h);
    return normValidNames.some(v => normH.includes(v));
  });
}

/**
 * Parse ngày tháng an toàn hơn
 */
function safeParseDate(val: any): Date | undefined {
  if (val instanceof Date) return val;
  if (!val) return undefined;

  if (typeof val === 'number') {
    return new Date(Math.round((val - 25569) * 86400 * 1000));
  }

  if (typeof val === 'string') {
    // Thử chuẩn ISO và các định dạng phổ biến
    let d = new Date(val);
    if (!isNaN(d.getTime())) return d;

    // Thử định dạng VN: dd/mm/yyyy
    const parts = val.split(/[/\-\s]/); 
    if (parts.length >= 3) {
      const day = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1; 
      let year = parseInt(parts[2], 10);
      if (year < 100) year += 2000;
      d = new Date(year, month, day);
      if (!isNaN(d.getTime())) return d;
    }
  }
  return undefined;
}

function getRowSignature(row: any): string {
  return `${row.normalizedKho}|${row.normalizedNguoiTao}|${row['Mã đơn hàng']}`;
}

self.onmessage = async (e) => {
  const { type, payload } = e.data;

  const debugLog: any = {
    step: 'start',
    totalRowsRaw: 0,
    headerRowIndex: -1,
    detectedHeaders: [],
    columnMapping: {},
    sampleRowsResult: [],
    error: null
  };

  try {
    if (type === 'IMPORT_FILE') {
      const { file, enableDeduplication } = payload;
      
      debugLog.step = 'reading_file_buffer';
      const arrayBuffer = await file.arrayBuffer();
      // GC hint
      let data: Uint8Array | null = new Uint8Array(arrayBuffer);
      
      debugLog.step = 'parsing_excel';
      // Đọc file với cấu hình tối ưu bộ nhớ nhất
      let workbook: XLSX.WorkBook | null = XLSX.read(data, { 
        type: 'array', 
        cellDates: true, 
        dense: true, 
        cellNF: false, 
        cellText: false,
        cellFormula: false,
        cellStyles: false
      });
      
      // Xóa buffer gốc ngay lập tức để giải phóng RAM
      data = null; 

      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      
      debugLog.step = 'converting_to_json';
      let rawRows: any[][] | null = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
      
      // Xóa workbook ngay lập tức
      workbook = null;

      debugLog.totalRowsRaw = rawRows.length;
      if (rawRows.length === 0) throw new Error("File rỗng (0 dòng).");

      // 1. Dò tìm dòng tiêu đề
      debugLog.step = 'detecting_header';
      let headerRowIndex = -1;
      let headers: string[] = [];
      
      // Mở rộng từ khóa tìm kiếm
      const requiredKeywords = ['ma don hang', 'so chung tu', 'ngay tao', 'ngay chung tu', 'trang thai'];

      // Quét 200 dòng đầu để tìm header
      for (let i = 0; i < Math.min(rawRows.length, 200); i++) {
        const row = rawRows[i];
        if (!row || row.length === 0) continue;
        
        const rowString = normalizeStr(row.join(' '));
        // Chỉ cần tìm thấy 2 trong số các từ khóa quan trọng
        const matchCount = requiredKeywords.reduce((acc, k) => acc + (rowString.includes(k) ? 1 : 0), 0);
        
        if (matchCount >= 2) {
          headerRowIndex = i;
          headers = row.map(c => String(c || '').trim());
          break;
        }
      }

      debugLog.headerRowIndex = headerRowIndex;
      debugLog.detectedHeaders = headers;

      if (headerRowIndex === -1) {
        throw new Error(`Không tìm thấy dòng tiêu đề. Vui lòng đảm bảo file có các cột: Mã đơn hàng, Ngày tạo, Trạng thái.`);
      }

      columnHeaders = headers;

      // 2. Map cột (Mở rộng alias tối đa)
      const idx = {
        maDonHang: getColIndex(headers, ['ma don hang', 'don hang', 'so chung tu', 'so ct', 'ma phieu', 'id', 'ma gd']),
        kho: getColIndex(headers, ['ma kho tao', 'ma kho', 'kho', 'store', 'site', 'chi nhanh']),
        xuat: getColIndex(headers, ['trang thai xuat', 'tinh trang xuat']),
        nguoiTao: getColIndex(headers, ['nguoi tao', 'nhan vien tao', 'nvbh', 'nhan vien', 'salesman']),
        trangThai: getColIndex(headers, ['trang thai ho so', 'loai ho so', 'tinh trang ho so']),
        nganhHang: getColIndex(headers, ['nganh hang', 'nganh']),
        nhomHang: getColIndex(headers, ['nhom hang', 'nhom']),
        soLuong: getColIndex(headers, ['so luong', 'sl', 'qty']),
        giaBan: getColIndex(headers, ['gia ban_1', 'gia ban', 'thanh tien', 'doanh thu', 'amount']),
        hinhThuc: getColIndex(headers, ['hinh thuc xuat', 'loai hinh']),
        tenSP: getColIndex(headers, ['ten san pham', 'san pham', 'item name']),
        ngayTao: getColIndex(headers, ['ngay tao', 'ngay chung tu', 'ngay ct', 'ngay mua']),
        
        // Điều kiện lọc
        huy: getColIndex(headers, ['trang thai huy', 'huy']),
        tra: getColIndex(headers, ['tinh trang nhap tra', 'nhap tra']),
        thuTien: getColIndex(headers, ['trang thai thu tien', 'thu tien'])
      };

      debugLog.columnMapping = idx;

      if (idx.ngayTao === -1) throw new Error("Không tìm thấy cột 'Ngày tạo' hoặc 'Ngày chứng từ'");
      
      // 3. Duyệt dữ liệu
      debugLog.step = 'processing_rows';
      
      // Cắt bỏ phần header khỏi mảng để duyệt data
      // Sử dụng vòng lặp for thủ công để tối ưu tốc độ cho mảng lớn
      const startIdx = headerRowIndex + 1;
      const endIdx = rawRows.length;
      
      const rowSignatures = new Set();
      const mappedData: any[] = [];
      let validCount = 0;
      let errorLogCount = 0;

      for (let i = startIdx; i < endIdx; i++) {
        const row = rawRows[i];
        if (!row || row.length === 0) continue;

        // Logic check điều kiện (Chuẩn hóa string trước khi check để tránh lỗi case)
        // Nếu không tìm thấy cột điều kiện, mặc định là THỎA MÃN (để tránh lọc sai do thiếu cột)
        const valHuy = idx.huy > -1 ? normalizeStr(row[idx.huy]) : '';
        const valTra = idx.tra > -1 ? normalizeStr(row[idx.tra]) : '';
        const valThu = idx.thuTien > -1 ? normalizeStr(row[idx.thuTien]) : '';

        // Logic "Chấp nhận nếu rỗng hoặc chứa từ khóa khẳng định chưa/đã"
        const isHuyValid = valHuy === '' || valHuy.includes('chua huy');
        const isTraValid = valTra === '' || valTra.includes('chua tra');
        // Với thu tiền, nếu không có cột thu tiền thì coi như đã thu (hoặc bỏ qua check này)
        const isThuValid = idx.thuTien === -1 || valThu === '' || valThu.includes('da thu') || valThu.includes('da thanh toan') || valThu.includes('hoan tat');

        if (!isHuyValid || !isTraValid || !isThuValid) {
          if (errorLogCount < 5) {
             const reason = [];
             if (!isHuyValid) reason.push(`Hủy="${row[idx.huy]}"`);
             if (!isTraValid) reason.push(`Trả="${row[idx.tra]}"`);
             if (!isThuValid) reason.push(`Thu="${row[idx.thuTien]}"`);
             debugLog.sampleRowsResult.push({ rowIndex: i + 1, reason: reason.join(', ') });
             errorLogCount++;
          }
          continue;
        }

        const ngayTaoVal = row[idx.ngayTao];
        const parsedDate = safeParseDate(ngayTaoVal);

        if (!parsedDate) {
           if (errorLogCount < 5) {
            debugLog.sampleRowsResult.push({ rowIndex: i + 1, reason: `Lỗi ngày: "${ngayTaoVal}"` });
            errorLogCount++;
           }
           continue;
        }

        const xuatValue = idx.xuat > -1 ? String(row[idx.xuat] || '') : '';
        
        // Tạo object nhẹ nhất có thể
        const mappedRow = {
          'Mã đơn hàng': idx.maDonHang > -1 ? row[idx.maDonHang] : '',
          'Mã kho tạo': idx.kho > -1 ? row[idx.kho] : '',
          'Trạng thái xuất': xuatValue,
          'Người tạo': idx.nguoiTao > -1 ? row[idx.nguoiTao] : '',
          'Trạng thái hồ sơ': idx.trangThai > -1 ? row[idx.trangThai] : '',
          'Ngành hàng': idx.nganhHang > -1 ? row[idx.nganhHang] : '',
          'Nhóm hàng': idx.nhomHang > -1 ? row[idx.nhomHang] : '',
          'Số lượng': idx.soLuong > -1 ? (Number(row[idx.soLuong]) || 0) : 0,
          'Giá bán_1': idx.giaBan > -1 ? (Number(row[idx.giaBan]) || 0) : 0,
          'Hình thức xuất': idx.hinhThuc > -1 ? row[idx.hinhThuc] : '',
          'Tên sản phẩm': idx.tenSP > -1 ? row[idx.tenSP] : '',
          
          normalizedKho: String(idx.kho > -1 ? row[idx.kho] || '' : ''),
          normalizedXuat: normalizeStr(xuatValue).includes('da') ? 'Đã' : 'Chưa',
          normalizedNguoiTao: String(idx.nguoiTao > -1 ? row[idx.nguoiTao] || '' : ''),
          normalizedTrangThai: String(idx.trangThai > -1 ? row[idx.trangThai] || '' : ''),
          parsedDate: parsedDate
        };

        if (enableDeduplication) {
          const sig = getRowSignature(mappedRow);
          if (rowSignatures.has(sig)) continue;
          rowSignatures.add(sig);
        }

        mappedData.push(mappedRow);
        validCount++;
      }

      // Giải phóng bộ nhớ rawRows ngay lập tức
      rawRows = null; 

      if (validCount === 0) {
        const debugStr = JSON.stringify(debugLog, null, 2);
        throw new Error(`DEBUG_INFO: ${debugStr}`);
      }

      cachedOriginalData = mappedData;
      
      // Xử lý thống kê
      const result = processDashboardData(cachedOriginalData);
      
      self.postMessage({ type: 'SUCCESS', payload: result });
    }

    if (type === 'APPLY_FILTER') {
      const filtered = applyAllFilters(cachedOriginalData, payload);
      const result = processDashboardData(filtered);
      self.postMessage({ type: 'FILTER_SUCCESS', payload: result });
    }
  } catch (error: any) {
    debugLog.error = error.message;
    // Format lại error để dễ đọc hơn trong console
    const msg = error.message.includes('DEBUG_INFO') 
      ? error.message 
      : `LỖI XỬ LÝ: ${error.message} \n\nCHI TIẾT KỸ THUẬT:\n${JSON.stringify(debugLog, null, 2)}`;
      
    self.postMessage({ type: 'ERROR', message: msg });
  }
};
