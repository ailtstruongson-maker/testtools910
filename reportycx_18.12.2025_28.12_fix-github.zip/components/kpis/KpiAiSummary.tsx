import React from 'react';

const KpiAiSummary: React.FC = () => {
    return null;
};

export default KpiAiSummary;
