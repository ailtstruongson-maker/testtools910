
// This file is deprecated to resolve casing conflicts.
// The implementation has been moved to components/views/tax/TaxComponents.tsx
export {};
