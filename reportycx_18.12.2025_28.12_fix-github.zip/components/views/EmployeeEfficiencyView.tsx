import React from 'react';

const EmployeeEfficiencyView: React.FC = () => {
    return null;
};

export default EmployeeEfficiencyView;
