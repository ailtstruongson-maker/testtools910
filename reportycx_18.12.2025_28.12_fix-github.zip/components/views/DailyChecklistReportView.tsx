import React from 'react';

const DailyChecklistReportView: React.FC = () => {
    return null;
};

export default DailyChecklistReportView;
