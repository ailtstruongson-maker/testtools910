import React from 'react';

const ReportBiUpdateView: React.FC = () => {
    return null;
};

export default ReportBiUpdateView;
