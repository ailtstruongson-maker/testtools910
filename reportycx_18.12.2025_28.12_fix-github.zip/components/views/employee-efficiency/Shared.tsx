import React from 'react';

export const Header: React.FC<any> = () => null;
export const ChangelogModal: React.FC<any> = () => null;
export const Toast: React.FC<any> = () => null;
export const LoadingOverlay: React.FC<any> = () => null;
export const AICompanion: React.FC<any> = () => null;
export const InputTabs: React.FC<any> = () => null;
