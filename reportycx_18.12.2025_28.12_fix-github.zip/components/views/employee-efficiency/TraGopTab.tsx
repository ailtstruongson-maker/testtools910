import React from 'react';

// FIX: Changed React.FC to React.FC<any> to allow passing props to this stub component and resolve the TypeScript error.
const TraGopTab: React.FC<any> = () => {
    return null;
};

export default TraGopTab;
