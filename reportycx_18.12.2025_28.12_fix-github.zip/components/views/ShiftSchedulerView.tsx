import React from 'react';

const ShiftSchedulerView: React.FC = () => {
    return null;
};

export default ShiftSchedulerView;
