import React from 'react';

const PlaceholderView: React.FC = () => {
    return null;
};

export default PlaceholderView;
