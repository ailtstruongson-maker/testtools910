import React from 'react';

const CompetitionCheckView: React.FC = () => {
    return null;
};

export default CompetitionCheckView;
