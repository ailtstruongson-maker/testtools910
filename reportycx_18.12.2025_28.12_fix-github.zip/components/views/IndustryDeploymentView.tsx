import React from 'react';

const IndustryDeploymentView: React.FC = () => {
    return null;
};

export default IndustryDeploymentView;
