import React from 'react';

const CouponConverterView: React.FC = () => {
    return null;
};

export default CouponConverterView;
