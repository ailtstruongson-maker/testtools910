// This file has been moved into HeadToHeadTab.tsx to simplify state management.
// This file can be deleted.
