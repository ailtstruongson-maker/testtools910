
// Global type definitions for external libraries loaded via CDN
declare const google: any;
declare const lucide: {
    createIcons: (options?: { root?: HTMLElement | null }) => void;
};
declare const Sortable: any;
declare const html2canvas: any;
